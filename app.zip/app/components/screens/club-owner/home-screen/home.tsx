import React from 'react';
import { View, StyleSheet ,TouchableOpacity,Text} from 'react-native';
import GradientTopBackground from '@/app/components/backgrounds/gradientTopBackground';
import Header from '@/app/components/screens/club-owner/home-screen/header'; // Adjust if the Header is elsewhere in the folder



const App = () => {
  return (
    <GradientTopBackground>
      <View style={styles.container}>
        <Header />
         
        {/* Add other components here */}
      </View>
    </GradientTopBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
