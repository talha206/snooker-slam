import React from 'react';
import { View, Text, Image, StyleSheet,TouchableOpacity } from 'react-native';
// eslint-disable-next-line import/no-unresolved
import Icon from 'react-native-vector-icons/Ionicons';
import useScreenSize from '@/hooks/useScreenSize';
import LinearGradient from 'react-native-linear-gradient';
// import { opacity } from 'react-native-reanimated/lib/typescript/reanimated2/Colors';


const DateNavigator = () => {
    return (
      <View style={styles.dateNavContainer}>
        <View style={styles.liveIndicator}>
          <Text style={styles.liveText}>LIVE</Text>
        </View>
    <View style={styles.datesection}>
        <TouchableOpacity style={styles.arrowback}>
          <Icon name="chevron-back-outline" size={24} color="rgba(255, 255, 255, 0.58)" />
         
          <Icon name="chevron-back-outline" size={24} color="#fff" />
         </TouchableOpacity>
        
        <View style={styles.dateItems}>
          {/* LIVE Date */}
          <Text style={styles.dateText} >September</Text>
           {/* <LinearGradient
        colors={['transparent', 'red']}
        start={{ x: 0.5, y: 1 }} // Start from bottom-center
        end={{ x: 0.5, y: 0 }}   // End at top-center
       >  */}
          <Text style={styles.dateTextActive}>Octuber</Text>
          {/* </LinearGradient>  */}
          <Text style={styles.dateText} >November</Text>
        </View>
         
        <TouchableOpacity style={styles.arrowforward}>
          <Icon name="chevron-forward-outline" size={24} color="#fff" /> 
          <Icon name="chevron-forward-outline" size={24} color="rgba(255, 255, 255, 0.58)" /> 
         </TouchableOpacity>
         </View>
    
        <TouchableOpacity>
          <Icon name="calendar-outline" size={24} color="#aaa" />
        </TouchableOpacity>
      </View>
      
    );
  };

const Header = () => {
  const { isSmall } = useScreenSize();

  return (
    <View>
    <View style={[styles.headerContainer, isSmall && styles.smallHeaderContainer]}>
      <Image source={require('@/assets/icon.png')} style={[styles.logo, isSmall && styles.smallLogo]} />
      <Text style={[styles.headerTitle, isSmall && styles.smallHeaderTitle]}>Overview</Text>
      <View style={styles.headerIcons}>
        <Icon name="search-outline" size={24} color="#fff" style={[styles.icon, isSmall && styles.smallIcon]} />
        <Icon name="notifications-outline" size={24} color="#fff" style={[styles.icon, isSmall && styles.smallIcon]} />
      </View>
      
    </View>
    <DateNavigator/>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
  },
  smallHeaderContainer: {
    padding: 10,
  },
  logo: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  smallLogo: {
    width: 20,
    height: 20,
  },
  headerTitle: {
    color: '#fff',
    fontSize: 32,
    fontWeight: 'bold',
    textAlign:'center',
  },
  smallHeaderTitle: {
    fontSize: 16,
  },
  headerIcons: {
    flexDirection: 'row',
  },
  icon: {
    marginRight: 10,
    padding: 12,
    borderRadius: 100,
    borderColor:  '#353535',
   borderWidth:1,
},
  smallIcon: {
    marginRight: 10,
    padding: 8,
  },
  datesection:{
    flexDirection:'row',
    justifyContent:'space-between',
    paddingHorizontal:20,
    paddingTop:20,
    borderWidth: 3,               // Sets the width of the border
    borderColor: '#353535',           // Sets the color of the border
    borderRadius: 25,              // Rounds the corners of the border
    borderStyle: 'solid',  
  },

  dateNavContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'rgba(26, 26, 26, 0.8)',  // Optional: Semi-transparent background for readability
    borderWidth: 3,               // Sets the width of the border
    borderTopColor: '#353535',           // Sets the color of the border
                   // Rounds the corners of the border
    borderStyle: 'solid', 
  },
  dateItems: {
    flexDirection: 'row',
    alignItems: 'center',
    // marginHorizontal:'10%',
  },
  liveIndicator: {
    backgroundColor: 'rgba(48, 238, 0, 1)',
    paddingHorizontal: 1,
    paddingVertical: 1,
    borderRadius: 5,
    marginRight: 10,
  },
  liveText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
    borderColor:'black',
    borderWidth: 4,     
    paddingHorizontal:7,     
    paddingVertical:2,      
     borderRadius: 5,              
    borderStyle: 'solid', 
  },
  dateText: {
    color: '#fff',
  
    marginHorizontal:20,
    paddingBottom:20,
    fontSize: 14,
  },
  dateTextActive: {
    color: '#fff',
    marginRight: 20,
    paddingBottom:20,
    fontSize: 14,
    fontWeight: 'bold',
    borderBottomColor:'red',
    borderBottomWidth:3,
    zIndex:10,
    
    
  },
  arrowforward:{
    flexDirection:'row',
  },
  arrowback:{
    flexDirection:'row',
  },
});

export default Header;
