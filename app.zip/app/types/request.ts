
export type Request = {
    club_name: string;
    club_owner_name: string;
}