export interface Role {
    name: string
}