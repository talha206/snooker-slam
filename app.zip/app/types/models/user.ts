import { Role } from './role'

export interface User {
    phoneNo: string
    role: Role
}