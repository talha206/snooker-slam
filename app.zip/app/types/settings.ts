export type SettingItem = {
    title: string;
    route: string;
}

export type InformationBox = {
    title: string
    value: any;
}