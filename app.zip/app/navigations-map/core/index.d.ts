
declare module '@/app/navigations-map/core' {
    export const CoreRouteNames: Record<string, string>;
    export const CoreRoutes: [];
}