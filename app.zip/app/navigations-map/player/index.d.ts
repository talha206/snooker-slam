declare module '@/app/navigations-map/player' {
    export const PlayerRouteNames: Record<string, string>;
    export const PlayerRoutes: [];
}