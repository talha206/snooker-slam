declare module '@/app/navigations-map/player' {
    export const ClubOwnerRouteNames: Record<string, string>;
    export const ClubRouteRoutes: [];
}